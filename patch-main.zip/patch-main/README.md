## Ordered reboot with RedHat host patching.

### Tags supported 

<pre>
reboot_redhat
reboot_windows
reboot_all
patch_redhat
</pre>